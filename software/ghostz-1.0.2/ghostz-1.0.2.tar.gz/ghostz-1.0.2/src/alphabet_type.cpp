/*
 * alphabet_type.cpp
 *
 *  Created on: 2010/09/14
 *      Author: shu
 */

#include "alphabet_type.h"

AlphabetType::~AlphabetType()
{}
