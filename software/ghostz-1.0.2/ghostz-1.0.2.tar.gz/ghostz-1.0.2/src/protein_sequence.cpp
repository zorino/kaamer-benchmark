/*
 * protein_sequence.cpp
 *
 *  Created on: 2011/04/11
 *      Author: shu
 */

#include "protein_sequence.h"
