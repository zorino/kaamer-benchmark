# kAAmer Web User Interface


The Web UI is a static web interface built with react and gatsby.

You need to compile the project from the source code directory from where kaamer was installed.

Requirements:
- nodejs
- npm
- gatsby

```shell
npm install -g gatsby
cd <kaamer-dir>/web/
npm install
gatsby build --prefix-paths
```

