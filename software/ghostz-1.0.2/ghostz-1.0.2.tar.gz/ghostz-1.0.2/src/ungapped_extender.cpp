/*
 * ungapped_extender.cpp
 *
 *  Created on: 2012/11/12
 *      Author: shu
 */

#include <iostream>
#include "edit_blocks.h"
#include "score_matrix.h"
#include "ungapped_extender.h"

using namespace std;

