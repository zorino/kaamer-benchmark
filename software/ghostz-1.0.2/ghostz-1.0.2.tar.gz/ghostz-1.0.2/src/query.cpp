/*
 * query.cpp
 *
 *  Created on: 2011/02/21
 *      Author: shu
 */

#include "query.h"

using namespace std;

Query::Query()
:name_(""), sequence_(0)
{}

Query::~Query()
{}
