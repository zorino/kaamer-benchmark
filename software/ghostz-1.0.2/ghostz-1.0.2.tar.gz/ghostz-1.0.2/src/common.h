/*
 * common.h
 *
 *  Created on: 2014/06/09
 *      Author: shu
 */

#ifndef COMMON_H_
#define COMMON_H_

#include <string>

namespace common {
static const std::string kVersion = "1.0.2";

}

#endif /* COMMON_H_ */
