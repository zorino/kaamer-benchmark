/*
 * dna.cpp
 *
 *  Created on: 2010/09/28
 *      Author: shu
 */

#include "dna_type.h"

using namespace std;

const string DnaType::kRegularLetters = "ACGT";
const string DnaType::kAmbiguousLetters = "";
const char DnaType::kUnknownLetter = 'N';
